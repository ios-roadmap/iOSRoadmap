//
//  IRDashboardLibrary.swift
//  IRDashboardLibrary
//
//  Created by Ömer Faruk Öztürk on 17.02.2025.
//

public struct IRDashboardLibrary {
    public init() {}
}
