//
//  IRDashboardTests.swift
//  IRDashboardTests
//
//  Created by Ömer Faruk Öztürk on 17.02.2025.
//

import Testing
@testable import IRDashboard

struct IRDashboardTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
